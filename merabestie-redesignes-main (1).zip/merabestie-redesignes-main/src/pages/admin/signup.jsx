import React from "react";
import AdminSignup from "../../components/admin/signup";

const SellerPage = () => {
  return <AdminSignup />;
};

export default SellerPage;

